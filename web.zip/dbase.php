<?php
  $server = 'localhost';
  $user = 'root';
  $password = '';
  $db = 'sup';

  $con = mysqli_connect($server , $user , $password , $db );
 ?>